#!/bin/bash

g++ -std=c++11 main.cpp -o proj2 && ./proj2

